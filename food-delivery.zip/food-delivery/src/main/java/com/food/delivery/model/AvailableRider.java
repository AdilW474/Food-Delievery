package com.food.delivery.model;

public record AvailableRider(Long riderId, Double distance) {
}
