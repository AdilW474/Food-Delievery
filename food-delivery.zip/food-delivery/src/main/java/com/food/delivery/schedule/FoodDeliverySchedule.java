package com.food.delivery.schedule;

public interface FoodDeliverySchedule {
}
